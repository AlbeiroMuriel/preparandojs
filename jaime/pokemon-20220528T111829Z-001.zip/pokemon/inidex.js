function crearPokemon() {
    const numeroPokemon = document.querySelector('#numeroPokemon').value;
    const divContainer = document.querySelector('#container');
    const divPadre = document.createElement('div');
    const imagen = document.createElement('img');
    const divImagen = document.createElement('div');
    const divContent = document.createElement('div');
    const nombrePokemon = document.createElement('h2');
    const inforPokemon = document.createElement('p');
    const textinforPokemon = document.createElement('p');
    const informacionPokemon = document.createElement('div');
    const tipoPokemon = document.createElement('div');
    tipoPokemon.classList.add('tipo');
    textinforPokemon.textContent='Tipo';
    inforPokemon.textContent = 'Lorem ipsum dolor sit amet consectetur adipisicing elit. Totam voluptate similique quia consequatur quam, aliquam dignissimos quae distinctio repellendus assumenda qui, perspiciatis, in magni.';
    nombrePokemon.textContent = `Pokemon #${numeroPokemon}`;
    divContent.classList.add('content');
    divPadre.classList.add('card');
    divImagen.classList.add('imgBx');
    informacionPokemon.classList.add('info');
    imagen.src = `./img/${numeroPokemon}.png`;
    divImagen.append(imagen);
    tipoPokemon.append(textinforPokemon);
    informacionPokemon.append(tipoPokemon);
    divContent.append(nombrePokemon, inforPokemon);
    divPadre.append(divImagen,divContent);
    divContainer.append(divPadre);


}